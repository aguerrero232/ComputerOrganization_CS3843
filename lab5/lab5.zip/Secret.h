
// Secret.h
//
// This file contains the "secret" string for Lab#5
//

// http://www.devtopics.com/101-more-great-computer-quotes/
char gSecret[] = "A computer once beat me at chess, but it was no match for me at kick boxing.";